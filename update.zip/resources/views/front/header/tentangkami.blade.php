@extends('front.layouts.master')

@section('content')

	<div id="contact-page" class="container">
    	<div class="bg">
	    	<div class="row">    		
	    		<div class="col-sm-12">    			   			
					<h2 class="mt-5">Tentang <strong>Kami</strong></h2>
					</div>
					<div class="contact-info">
					    <div class="col-sm-12" style="margin-bottom:2em">   
    					     
    					       <img src="{{ asset('fotonya/DSC_0308.JPG')}}"  style="float: left; height: 100px; margin: 10px 10px 10px 0px; width: auto;" />
    					      
    					     <img src="{{ asset('fotonya/DSC_0311.JPG')}}"   style="float: left; height: 100px; margin: 10px 10px 10px 0px; width: auto;" />
    					     
    					      <img src="{{ asset('fotonya/DSC_0312.JPG')}}"  style="float: left; height: 100px; margin: 10px 10px 10px 0px; width: auto;" />
					    </div><br><br><br><br>
						<address>
	    				<p style="text-align:justify;"> Annyeong haseyo! </p>
	    				<p> CV. Siti Fathonah sekarang hadir dengan sebuah website, yaitu SF Shop. CV ini berdiri sejak tahun 2009, mulanya kami hanya melakukan pemesanan melalui manual saja, namun saat ini kami mulai membangun ecommerce agar mudah dijangkau oleh para konsumen. 
	    					Nah, bagi kalian penggemar makanan korea atau drama korea yang sudah tidak asing lagi dengan kimchi 
	    					sekarang sudah bisa loh pesan online melalui SF Shop ini. Kimchi yang dijajakan 100% original dan berbahan dasar asli. Sayur yang dipakai pun sangat fresh! 
	    					Selain itu, kami juga menyediakan beberapa bumbu serta saus khas korea selatan (gochujang).</p>
	    				</address>
	    			</div>
				</div>			 		
			</div>
			<div class="contact-info">
	    				<address>

							<i class="fa fa-clock-o"></i>  Jam Operasional
							<p align:"left">Senin-Jumat: 07.00 - 17.00 WIB</p>
							<p style="text-align:justify;">Sabtu: 09.00 - 17.00 WIB</p>
							<p style="text-align:justify;">Hari Minggu & Hari Libur Nasional: Tidak Beroperasi</p><br>

							<i class="fa fa-map-marker"></i>   Alamat
							<p> Jalan Pondok Kelapa Selatan No. 70 RT 006/012, Pondok Kelapa, Duren Sawit. </p><br>

							<i class="fa fa-phone"></i>   Telepon
							<p style="text-align:justify;">Hp: +082260895858</p>
							<p style="text-align:justify;">Telp: +86907132</p>
							<p style="text-align:justify;">Fax: 021 86907131</p>
							<p style="text-align:justify;">Email: happinessdelighted@gmail.com</p><br>
	    				</address>
	    			</div>
				</div>			 		
			<div class="row">  	
	    		<div class="col-sm-8">
	    		</div>
	    		<div class="col-sm-4">
    			</div>    			
	    	</div>      	
    	</div>	






@endsection